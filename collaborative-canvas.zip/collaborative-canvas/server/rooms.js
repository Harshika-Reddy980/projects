export class RoomManager {
    constructor() {
        this.rooms = new Map();
    }
    
    joinRoom(roomId, userId, userName, userColor) {
        if (!this.rooms.has(roomId)) {
            this.rooms.set(roomId, {
                users: new Map(),
                drawingHistory: [],
                undoneHistory: []
            });
        }
        
        const room = this.rooms.get(roomId);
        room.users.set(userId, {
            id: userId,
            name: userName,
            color: userColor,
            joinedAt: new Date()
        });
    }
    
    leaveRoom(roomId, userId) {
        const room = this.rooms.get(roomId);
        if (room) {
            room.users.delete(userId);
        }
    }
    
    getRoomUsers(roomId) {
        const room = this.rooms.get(roomId);
        return room ? Array.from(room.users.values()) : [];
    }
    
    getRoomState(roomId) {
        const room = this.rooms.get(roomId);
        return {
            drawingHistory: room ? room.drawingHistory : [],
            users: this.getRoomUsers(roomId)
        };
    }
    
    addDrawingOperation(roomId, operation) {
        const room = this.rooms.get(roomId);
        if (room) {
            room.drawingHistory.push({
                ...operation,
                timestamp: Date.now(),
                id: this.generateId()
            });
            room.undoneHistory = [];
        }
    }
    
    undo(roomId) {
        const room = this.rooms.get(roomId);
        if (room && room.drawingHistory.length > 0) {
            const undoneOp = room.drawingHistory.pop();
            room.undoneHistory.push(undoneOp);
            return undoneOp;
        }
        return null;
    }
    
    redo(roomId) {
        const room = this.rooms.get(roomId);
        if (room && room.undoneHistory.length > 0) {
            const redoneOp = room.undoneHistory.pop();
            room.drawingHistory.push(redoneOp);
            return redoneOp;
        }
        return null;
    }
    
    clearCanvas(roomId) {
        const room = this.rooms.get(roomId);
        if (room) {
            room.drawingHistory = [];
            room.undoneHistory = [];
        }
    }
    
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
}