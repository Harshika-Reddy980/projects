// This file will handle the drawing state management
// We'll expand this later for more complex operations

export class DrawingState {
    constructor() {
        this.operations = [];
        this.undoneOperations = [];
    }
    
    addOperation(operation) {
        this.operations.push({
            ...operation,
            id: this.generateId(),
            timestamp: Date.now()
        });
        this.undoneOperations = []; // Clear redo stack
    }
    
    undo() {
        if (this.operations.length > 0) {
            const operation = this.operations.pop();
            this.undoneOperations.push(operation);
            return operation;
        }
        return null;
    }
    
    redo() {
        if (this.undoneOperations.length > 0) {
            const operation = this.undoneOperations.pop();
            this.operations.push(operation);
            return operation;
        }
        return null;
    }
    
    clear() {
        this.operations = [];
        this.undoneOperations = [];
    }
    
    getState() {
        return this.operations;
    }
    
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
}