import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { RoomManager } from './rooms.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const roomManager = new RoomManager();

// Serve static files from client directory
app.use(express.static(join(__dirname, '../client')));

// Routes
app.get('/', (req, res) => {
    res.sendFile(join(__dirname, '../client/index.html'));
});

// WebSocket connection handling
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    
    // Generate a random color for this user
    const userColor = getRandomColor();
    const userName = `User${Math.floor(Math.random() * 1000)}`;
    
    // Join default room
    const roomId = 'default-room';
    roomManager.joinRoom(roomId, socket.id, userName, userColor);
    socket.join(roomId);
    
    // Send current room state to new user
    const roomState = roomManager.getRoomState(roomId);
    socket.emit('user-connected', {
        userId: socket.id,
        userName,
        userColor,
        roomState
    });
    
    // Notify other users about new user
    socket.to(roomId).emit('user-joined', {
        userId: socket.id,
        userName,
        userColor
    });
    
    // Send current users list to all clients in room
    updateUsersList(roomId);
    
    // Drawing events
    socket.on('draw-start', (data) => {
        console.log('Draw start:', socket.id, data);
        socket.to(roomId).emit('remote-draw-start', {
            ...data,
            userId: socket.id,
            userColor
        });
    });
    
    socket.on('draw-move', (data) => {
        socket.to(roomId).emit('remote-draw-move', {
            ...data,
            userId: socket.id,
            userColor
        });
    });
    
    socket.on('draw-end', (data) => {
        // Add drawing operation to room history
        roomManager.addDrawingOperation(roomId, data);
        
        socket.to(roomId).emit('remote-draw-end', {
            ...data,
            userId: socket.id
        });
    });
    
    socket.on('cursor-move', (data) => {
        socket.to(roomId).emit('remote-cursor-move', {
            ...data,
            userId: socket.id,
            userColor
        });
    });
    
    // Undo/Redo events
    socket.on('undo-request', () => {
        const undoneOp = roomManager.undo(roomId);
        if (undoneOp) {
            io.to(roomId).emit('operation-undone', undoneOp);
        }
    });
    
    socket.on('redo-request', () => {
        const redoneOp = roomManager.redo(roomId);
        if (redoneOp) {
            io.to(roomId).emit('operation-redone', redoneOp);
        }
    });
    
    socket.on('clear-canvas', () => {
        roomManager.clearCanvas(roomId);
        io.to(roomId).emit('canvas-cleared');
    });
    
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        roomManager.leaveRoom(roomId, socket.id);
        socket.to(roomId).emit('user-left', socket.id);
        updateUsersList(roomId);
    });
    
    function updateUsersList(roomId) {
        const users = roomManager.getRoomUsers(roomId);
        io.to(roomId).emit('users-updated', users);
    }
});

function getRandomColor() {
    const colors = [
        '#e74c3c', '#3498db', '#2ecc71', '#f39c12', 
        '#9b59b6', '#1abc9c', '#d35400', '#c0392b'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`🎨 Collaborative Canvas ready!`);
});