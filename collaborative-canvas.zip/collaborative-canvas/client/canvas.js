export class DrawingCanvas {
    constructor(canvasElement, websocketManager) {
        this.canvas = canvasElement;
        this.ctx = canvasElement.getContext('2d');
        this.wsManager = websocketManager;
        this.isDrawing = false;
        this.currentTool = 'brush';
        this.currentColor = '#000000';
        this.brushSize = 5;
        this.lastX = 0;
        this.lastY = 0;
        
        // Store remote drawing contexts
        this.remoteDrawings = new Map();
        
        // Initialize canvas size
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Set initial canvas style
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.ctx.globalCompositeOperation = 'source-over';
        
        this.setupEventListeners();
    }
    
    resizeCanvas() {
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        
        // Redraw existing content if needed
        this.redraw();
    }
    
    setupEventListeners() {
        // Mouse events
        this.canvas.addEventListener('mousedown', this.startDrawing.bind(this));
        this.canvas.addEventListener('mousemove', this.draw.bind(this));
        this.canvas.addEventListener('mouseup', this.stopDrawing.bind(this));
        this.canvas.addEventListener('mouseout', this.stopDrawing.bind(this));
        
        // Touch events for mobile
        this.canvas.addEventListener('touchstart', this.handleTouchStart.bind(this));
        this.canvas.addEventListener('touchmove', this.handleTouchMove.bind(this));
        this.canvas.addEventListener('touchend', this.stopDrawing.bind(this));
        
        // Cursor movement tracking
        this.canvas.addEventListener('mousemove', this.trackCursor.bind(this));
    }
    
    startDrawing(e) {
        this.isDrawing = true;
        const pos = this.getMousePos(e);
        this.lastX = pos.x;
        this.lastY = pos.y;
        
        // Start local drawing
        this.ctx.beginPath();
        this.ctx.moveTo(this.lastX, this.lastY);
        
        // Send drawing start to server
        if (this.wsManager) {
            this.wsManager.emitDrawStart({
                x: this.lastX,
                y: this.lastY,
                tool: this.currentTool,
                color: this.currentColor,
                size: this.brushSize
            });
        }
    }
    
    draw(e) {
        if (!this.isDrawing) return;
        
        const pos = this.getMousePos(e);
        
        // Local drawing
        this.ctx.lineWidth = this.brushSize;
        
        if (this.currentTool === 'eraser') {
            this.ctx.globalCompositeOperation = 'destination-out';
            this.ctx.strokeStyle = 'rgba(0,0,0,1)';
        } else {
            this.ctx.globalCompositeOperation = 'source-over';
            this.ctx.strokeStyle = this.currentColor;
        }
        
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();
        
        // Send drawing data to server
        if (this.wsManager) {
            this.wsManager.emitDrawMove({
                x: pos.x,
                y: pos.y,
                tool: this.currentTool,
                color: this.currentColor,
                size: this.brushSize
            });
        }
        
        this.lastX = pos.x;
        this.lastY = pos.y;
    }
    
    stopDrawing() {
        if (this.isDrawing) {
            this.isDrawing = false;
            this.ctx.beginPath();
            
            // Send drawing end to server
            if (this.wsManager) {
                this.wsManager.emitDrawEnd({
                    tool: this.currentTool
                });
            }
        }
    }
    
    trackCursor(e) {
        const pos = this.getMousePos(e);
        
        // Send cursor position to server
        if (this.wsManager) {
            this.wsManager.emitCursorMove({
                x: pos.x,
                y: pos.y
            });
        }
    }
    
    handleTouchStart(e) {
        e.preventDefault();
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent('mousedown', {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        this.canvas.dispatchEvent(mouseEvent);
    }
    
    handleTouchMove(e) {
        e.preventDefault();
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent('mousemove', {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        this.canvas.dispatchEvent(mouseEvent);
    }
    
    getMousePos(e) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }
    
    // Handle remote drawing
    startRemoteDrawing(data) {
        // Create a temporary canvas for this remote user's current stroke
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = this.canvas.width;
        tempCanvas.height = this.canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        
        // Configure the drawing context
        tempCtx.lineCap = 'round';
        tempCtx.lineJoin = 'round';
        tempCtx.lineWidth = data.size;
        
        if (data.tool === 'eraser') {
            tempCtx.globalCompositeOperation = 'destination-out';
            tempCtx.strokeStyle = 'rgba(0,0,0,1)';
        } else {
            tempCtx.globalCompositeOperation = 'source-over';
            tempCtx.strokeStyle = data.userColor || data.color;
        }
        
        tempCtx.beginPath();
        tempCtx.moveTo(data.x, data.y);
        
        this.remoteDrawings.set(data.userId, {
            canvas: tempCanvas,
            ctx: tempCtx,
            lastX: data.x,
            lastY: data.y
        });
        
        this.redraw();
    }
    
    drawRemote(data) {
        const remoteDrawing = this.remoteDrawings.get(data.userId);
        if (remoteDrawing) {
            remoteDrawing.ctx.lineTo(data.x, data.y);
            remoteDrawing.ctx.stroke();
            remoteDrawing.lastX = data.x;
            remoteDrawing.lastY = data.y;
            
            this.redraw();
        }
    }
    
    endRemoteDrawing(userId) {
        // Merge the temporary drawing into the main canvas
        const remoteDrawing = this.remoteDrawings.get(userId);
        if (remoteDrawing) {
            this.ctx.drawImage(remoteDrawing.canvas, 0, 0);
            this.remoteDrawings.delete(userId);
        }
    }
    
    redraw() {
        // Clear the main canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Redraw all remote drawings
        this.remoteDrawings.forEach((drawing) => {
            this.ctx.drawImage(drawing.canvas, 0, 0);
        });
    }
    
    setTool(tool) {
        this.currentTool = tool;
    }
    
    setColor(color) {
        this.currentColor = color;
    }
    
    setBrushSize(size) {
        this.brushSize = size;
    }
    
    clearCanvas() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.remoteDrawings.clear();
    }
    
    // Method to get canvas data (for saving/synchronization)
    getCanvasData() {
        return this.canvas.toDataURL();
    }
}