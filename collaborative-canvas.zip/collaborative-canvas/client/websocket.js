export class WebSocketManager {
    constructor() {
        this.socket = io();
        this.isConnected = false;
        this.setupEventHandlers();
    }
    
    setupEventHandlers() {
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.isConnected = true;
        });
        
        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.isConnected = false;
        });
        
        this.socket.on('user-connected', (data) => {
            console.log('User connected data:', data);
            if (this.onUserConnected) {
                this.onUserConnected(data);
            }
        });
        
        this.socket.on('user-joined', (data) => {
            console.log('New user joined:', data);
            if (this.onUserJoined) {
                this.onUserJoined(data);
            }
        });
        
        this.socket.on('user-left', (userId) => {
            console.log('User left:', userId);
            if (this.onUserLeft) {
                this.onUserLeft(userId);
            }
        });
        
        this.socket.on('users-updated', (users) => {
            console.log('Users updated:', users);
            if (this.onUsersUpdated) {
                this.onUsersUpdated(users);
            }
        });
        
        this.socket.on('remote-draw-start', (data) => {
            if (this.onRemoteDrawStart) {
                this.onRemoteDrawStart(data);
            }
        });
        
        this.socket.on('remote-draw-move', (data) => {
            if (this.onRemoteDrawMove) {
                this.onRemoteDrawMove(data);
            }
        });
        
        this.socket.on('remote-draw-end', (data) => {
            if (this.onRemoteDrawEnd) {
                this.onRemoteDrawEnd(data);
            }
        });
        
        this.socket.on('remote-cursor-move', (data) => {
            if (this.onRemoteCursorMove) {
                this.onRemoteCursorMove(data);
            }
        });
        
        this.socket.on('operation-undone', (operation) => {
            if (this.onOperationUndone) {
                this.onOperationUndone(operation);
            }
        });
        
        this.socket.on('operation-redone', (operation) => {
            if (this.onOperationRedone) {
                this.onOperationRedone(operation);
            }
        });
        
        this.socket.on('canvas-cleared', () => {
            if (this.onCanvasCleared) {
                this.onCanvasCleared();
            }
        });
    }
    
    // Drawing events
    emitDrawStart(data) {
        this.socket.emit('draw-start', data);
    }
    
    emitDrawMove(data) {
        this.socket.emit('draw-move', data);
    }
    
    emitDrawEnd(data) {
        this.socket.emit('draw-end', data);
    }
    
    emitCursorMove(data) {
        this.socket.emit('cursor-move', data);
    }
    
    // Action events
    emitUndoRequest() {
        this.socket.emit('undo-request');
    }
    
    emitRedoRequest() {
        this.socket.emit('redo-request');
    }
    
    emitClearCanvas() {
        this.socket.emit('clear-canvas');
    }
}