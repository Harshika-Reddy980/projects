import { DrawingCanvas } from './canvas.js';
import { WebSocketManager } from './websocket.js';

class CollaborativeCanvasApp {
    constructor() {
        this.wsManager = new WebSocketManager();
        this.canvas = new DrawingCanvas(document.getElementById('drawing-canvas'), this.wsManager);
        this.remoteCursors = new Map();
        
        this.setupUI();
        this.setupWebSocketHandlers();
        this.initializeApp();
    }
    
    setupUI() {
        // Tool buttons
        document.getElementById('brush').addEventListener('click', () => {
            this.setActiveTool('brush');
            this.canvas.setTool('brush');
        });
        
        document.getElementById('eraser').addEventListener('click', () => {
            this.setActiveTool('eraser');
            this.canvas.setTool('eraser');
        });
        
        // Color picker
        document.getElementById('color-picker').addEventListener('input', (e) => {
            this.canvas.setColor(e.target.value);
        });
        
        // Brush size
        const brushSize = document.getElementById('brush-size');
        const brushSizeValue = document.getElementById('brush-size-value');
        
        brushSize.addEventListener('input', (e) => {
            const size = e.target.value;
            brushSizeValue.textContent = `${size}px`;
            this.canvas.setBrushSize(parseInt(size));
        });
        
        // Action buttons
        document.getElementById('undo').addEventListener('click', () => {
            this.undo();
        });
        
        document.getElementById('redo').addEventListener('click', () => {
            this.redo();
        });
        
        document.getElementById('clear').addEventListener('click', () => {
            this.clearCanvas();
        });
    }
    
    setupWebSocketHandlers() {
        // User management
        this.wsManager.onUsersUpdated = (users) => {
            this.updateUsersList(users);
        };
        
        this.wsManager.onUserJoined = (userData) => {
            this.addUserIndicator(userData.userName, userData.userColor);
        };
        
        this.wsManager.onUserLeft = (userId) => {
            this.removeUserIndicator(userId);
            this.removeRemoteCursor(userId);
        };
        
        // Drawing events - THESE ARE THE KEY FUNCTIONS!
        this.wsManager.onRemoteDrawStart = (data) => {
            this.canvas.startRemoteDrawing(data);
        };
        
        this.wsManager.onRemoteDrawMove = (data) => {
            this.canvas.drawRemote(data);
        };
        
        this.wsManager.onRemoteDrawEnd = (data) => {
            this.canvas.endRemoteDrawing(data.userId);
        };
        
        this.wsManager.onRemoteCursorMove = (data) => {
            this.updateRemoteCursor(data);
        };
        
        // Global actions
        this.wsManager.onOperationUndone = (operation) => {
            this.handleGlobalUndo(operation);
        };
        
        this.wsManager.onOperationRedone = (operation) => {
            this.handleGlobalRedo(operation);
        };
        
        this.wsManager.onCanvasCleared = () => {
            this.canvas.clearCanvas();
        };
    }
    
    setActiveTool(tool) {
        document.querySelectorAll('.tool').forEach(btn => {
            btn.classList.remove('active');
        });
        
        if (tool === 'brush') {
            document.getElementById('brush').classList.add('active');
        } else if (tool === 'eraser') {
            document.getElementById('eraser').classList.add('active');
        }
    }
    
    undo() {
        this.wsManager.emitUndoRequest();
    }
    
    redo() {
        this.wsManager.emitRedoRequest();
    }
    
    clearCanvas() {
        if (confirm('Are you sure you want to clear the canvas for all users?')) {
            this.wsManager.emitClearCanvas();
        }
    }
    
    updateUsersList(users) {
        const usersContainer = document.getElementById('users-container');
        usersContainer.innerHTML = '';
        
        users.forEach(user => {
            this.addUserIndicator(user.name, user.color);
        });
    }
    
    addUserIndicator(username, color) {
        const usersContainer = document.getElementById('users-container');
        const userElement = document.createElement('div');
        userElement.className = 'user-indicator';
        userElement.style.backgroundColor = color;
        userElement.textContent = username;
        userElement.dataset.userId = username;
        usersContainer.appendChild(userElement);
    }
    
    removeUserIndicator(userId) {
        const userElement = document.querySelector(`[data-user-id="${userId}"]`);
        if (userElement) {
            userElement.remove();
        }
    }
    
    updateRemoteCursor(data) {
        let cursor = this.remoteCursors.get(data.userId);
        const container = document.getElementById('cursors-container');
        
        if (!cursor) {
            cursor = document.createElement('div');
            cursor.className = 'remote-cursor';
            cursor.style.color = data.userColor;
            container.appendChild(cursor);
            this.remoteCursors.set(data.userId, cursor);
        }
        
        cursor.style.left = data.x + 'px';
        cursor.style.top = data.y + 'px';
        cursor.title = data.userName || `User ${data.userId}`;
    }
    
    removeRemoteCursor(userId) {
        const cursor = this.remoteCursors.get(userId);
        if (cursor) {
            cursor.remove();
            this.remoteCursors.delete(userId);
        }
    }
    
    handleGlobalUndo(operation) {
        console.log('Global undo:', operation);
        // Will implement fully in next step
        this.canvas.clearCanvas();
    }
    
    handleGlobalRedo(operation) {
        console.log('Global redo:', operation);
        // Will implement fully in next step
    }
    
    initializeApp() {
        console.log('Collaborative Canvas App Initialized');
        console.log('Real-time drawing is now enabled!');
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CollaborativeCanvasApp();
});